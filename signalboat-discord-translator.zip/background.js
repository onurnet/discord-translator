// Discord Otomatik Çevirmen Background Script
chrome.runtime.onInstalled.addListener(() => {
  // Default settings
  chrome.storage.sync.set({
    isEnabled: true,
    targetLanguage: 'en',
    sourceLanguage: 'auto',
    translationAPI: 'libre'
  });
});

// Popup'tan gelen mesajları işle
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'getSettings') {
    chrome.storage.sync.get(
      ['isEnabled', 'targetLanguage', 'sourceLanguage', 'translationAPI'],
      (result) => {
        sendResponse(result);
      }
    );
    return true; // Async response için
  }

  if (request.action === 'saveSettings') {
    chrome.storage.sync.set(request.settings, () => {
      // Tüm Discord sekmelerine ayarları gönder
      chrome.tabs.query({ url: 'https://discord.com/*' }, (tabs) => {
        tabs.forEach((tab) => {
          chrome.tabs.sendMessage(tab.id, {
            action: 'updateSettings',
            settings: request.settings
          });
        });
      });
      sendResponse({ success: true });
    });
    return true;
  }

  if (request.action === 'translate') {
    // Çeviri isteğini işle
    translateText(
      request.text,
      request.sourceLanguage,
      request.targetLanguage,
      request.translationAPI
    )
      .then((translatedText) => {
        sendResponse({ success: true, translatedText: translatedText });
      })
      .catch((error) => {
        console.error('Çeviri hatası:', error);
        sendResponse({ success: false, error: error.message });
      });
    return true; // Async response için
  }
});

// Çeviri fonksiyonu
async function translateText(
  text,
  sourceLanguage,
  targetLanguage,
  translationAPI
) {
  if (translationAPI === 'libre') {
    try {
      // LibreTranslate API (daha iyi kalite)
      const response = await fetch('https://libretranslate.de/translate', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          q: text,
          source: sourceLanguage === 'auto' ? 'auto' : sourceLanguage,
          target: targetLanguage,
          format: 'text'
        })
      });

      if (response.ok) {
        const data = await response.json();
        if (data.translatedText) {
          return data.translatedText;
        }
      }
    } catch (error) {
      console.log('LibreTranslate başarısız, Google Translate deneniyor...');
    }
  }

  try {
    // Google Translate API (fallback)
    const response = await fetch(
      `https://translate.googleapis.com/translate_a/single?client=gtx&sl=${sourceLanguage}&tl=${targetLanguage}&dt=t&q=${encodeURIComponent(
        text
      )}`
    );

    if (response.ok) {
      const data = await response.json();
      let fullTranslation = '';
      if (data[0] && Array.isArray(data[0])) {
        data[0].forEach((part) => {
          if (part && part[0]) {
            fullTranslation += part[0];
          }
        });
      }
      return fullTranslation || data[0]?.[0]?.[0] || null;
    }
  } catch (error) {
    console.error('Çeviri API hatası:', error);
  }

  return null;
}

// Eklenti ikonuna tıklandığında popup'ı aç
chrome.action.onClicked.addListener((tab) => {
  if (tab.url && tab.url.includes('discord.com')) {
    chrome.action.setPopup({ popup: 'popup.html' });
  }
});
